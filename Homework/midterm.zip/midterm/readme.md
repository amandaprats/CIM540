# tata, beginner's guide

Welcome to tata, a lifestyle brand and subscription service for young girls. Every month, girls will receive a toiletry bag that will contain 18 pads and 3 tampons as well as an informative zine.

Most girls learn about their menstrual cycle from women in their lives, such as their mother or older sister. This leaves a lot of girls with gaps in their understanding of their bodies, and many girls with no one to turn to for information. Tata aims to be a resource to help educate girls about their bodies and prepare them for their period. To do that, Tata will donate a bag to a girl in need for every bag purchased.

This guide is a digital version of the 'zine girls will receive with their first bag. Interaction points will include buttons, hitzones, mouseX and mouseY, and key presses.  
